import React, { useState } from 'react';
import { 
  Modal, 
  Text, 
  TextInput, 
  Pressable, 
  View, 
  FlatList, 
  StyleSheet, 
  Image 
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Calendar } from 'react-native-calendars';

const App = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [events, setEvents] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedDate, setSelectedDate] = useState(null);
  const [editingEvent, setEditingEvent] = useState(null);

  const addEvent = () => {
    if (title && description && selectedDate) {
      const newEvent = { id: Math.random().toString(), title, description, date: selectedDate };
      setEvents([...events, newEvent]);
      setTitle('');
      setDescription('');
      setSelectedDate(null);
      setModalVisible(false);
    }
  };

  const deleteEvent = (id) => {
    const updatedEvents = events.filter(event => event.id !== id);
    setEvents(updatedEvents);
  };

  const editEvent = (event) => {
    setEditingEvent(event);
    setTitle(event.title);
    setDescription(event.description);
    setSelectedDate(event.date);
    setEditModalVisible(true);
  };

  const updateEvent = () => {
    const updatedEvents = events.map(event => {
      if (event.id === editingEvent.id) {
        return { ...event, title, description, date: selectedDate };
      }
      return event;
    });
    setEvents(updatedEvents);
    setTitle('');
    setDescription('');
    setSelectedDate(null);
    setEditingEvent(null);
    setEditModalVisible(false);
  };

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.eventTitle}>{item.title}</Text>
        <View style={styles.iconContainer}>
          <Pressable onPress={() => deleteEvent(item.id)}>
            <Feather name="trash-2" size={20} color="red" />
          </Pressable>
          <Pressable onPress={() => editEvent(item)}>
            <Feather name="edit" size={20} color="#007AFF" style={styles.editIcon} />
          </Pressable>
        </View>
      </View>
      <Text style={styles.eventDescription}>{item.description}</Text>
      <Text style={styles.eventDate}>Date: {item.date}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Agenda de Tarefas</Text>
        <Feather name="calendar" size={24} color="#007AFF" />
      </View>

      <Image
        source={{ uri: 'https://cdn-icons-png.flaticon.com/512/2721/2721299.png' }}
        style={styles.image}
        resizeMode="contain"
      />

      <FlatList
        data={events}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.flatListContent}
      />

      <Pressable
        style={styles.addButton}
        onPress={() => setModalVisible(true)}
      >
        <Feather name="plus" size={24} color="white" />
        <Text style={styles.addButtonText}>Adicionar Tarefa</Text>
      </Pressable>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalBackground}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>Adicionar nova tarefa</Text>
              <TextInput
                style={styles.input}
                placeholder="Título"
                value={title}
                onChangeText={setTitle}
              />
              <TextInput
                style={styles.input}
                placeholder="Descrição"
                value={description}
                onChangeText={setDescription}
              />
              <Calendar
                onDayPress={(day) => setSelectedDate(day.dateString)}
                markedDates={selectedDate ? { [selectedDate]: { selected: true, selectedColor: '#007AFF' } } : {}}
              />
              <Pressable
                style={[styles.button, styles.buttonClose]}
                onPress={addEvent}
              >
                <Text style={styles.textStyle}>Adicionar</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        animationType="slide"
        transparent={true}
        visible={editModalVisible}
        onRequestClose={() => setEditModalVisible(false)}
      >
        <View style={styles.modalBackground}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>Editar tarefa</Text>
              <TextInput
                style={styles.input}
                placeholder="Título"
                value={title}
                onChangeText={setTitle}
              />
              <TextInput
                style={styles.input}
                placeholder="Descrição"
                value={description}
                onChangeText={setDescription}
              />
              <Calendar
                onDayPress={(day) => setSelectedDate(day.dateString)}
                markedDates={selectedDate ? { [selectedDate]: { selected: true, selectedColor: '#007AFF' } } : {}}
              />
              <Pressable
                style={[styles.button, styles.buttonClose]}
                onPress={updateEvent}
              >
                <Text style={styles.textStyle}>Salvar</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
    paddingTop: 50,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#rgb(249 249 249)',
    paddingVertical: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    backgroundColor: '#007AFF',
    marginTop: 20,
    width: 200,
  },
  addButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: '#007AFF',
    borderRadius: 30,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
    elevation: 5,
  },
  addButtonText: {
    fontSize: 16,
    color: 'white',
    marginLeft: 10,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  input: {
    height: 40,
    borderColor: '#999',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    width: 200,
  },
  card: {
    backgroundColor: '#E1F5FE',
    borderRadius: 10,
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    width: '90%',
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  eventDescription: {
    fontSize: 16,
    color: '#666',
  },
  eventDate: {
    fontSize: 14,
    color: '#888',
  },
  flatListContent: {
    paddingBottom: 100,
  },
  image: {
    width: 300, 
    height: 300, 
    alignSelf: 'center', 
    marginBottom: 20,
    marginTop: '15px',
  },
  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editIcon: {
    marginLeft: 10,
  },
});

export default App;
